#ifndef _TEXT_OBJECT_H_
#define _TEXT_OBJECT_H_

#include <string>

using namespace std;

class TextObject
{
	public:
		string text;
		void draw();
};

#endif
