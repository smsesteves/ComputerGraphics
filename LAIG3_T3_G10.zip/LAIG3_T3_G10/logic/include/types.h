#ifndef TYPES_H
#define TYPES_H

#define BOARDSIZE 7


#endif