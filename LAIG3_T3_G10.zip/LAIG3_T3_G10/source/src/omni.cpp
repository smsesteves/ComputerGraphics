#include "omni.h"

void Omni::setIdI(int id){
	this->idI = id;
}

