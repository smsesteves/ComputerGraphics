#include "Prong.h"

Prong::Prong(string dir)
{
	this->dir=dir;
}

string Prong::getDir()
{
	return dir;
}