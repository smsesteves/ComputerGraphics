#ifndef PRIMITIVE_H
#define PRIMITIVE_H

#include <string>
#include <vector>
#include "glui.h"
#include "appearance.h"
#include "animation.h"
#include "linearAnimation.h"

using namespace std;

class Primitive
{
private:
	
public:
	virtual void draw(){};
};

#endif