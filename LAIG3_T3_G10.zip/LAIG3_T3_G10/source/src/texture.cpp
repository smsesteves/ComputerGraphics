#include "texture.h"

void Texture::setTId(string id){
	this->id = id;
}

void Texture::setTPath(string filePath){
	this->filePath = filePath;
}
